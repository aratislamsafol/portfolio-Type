import Main from "./components/pages/Main"
import './assets/css/style.scss';
function App() {
  return (
    <>
      <Main />
    </>
  )
}

export default App
