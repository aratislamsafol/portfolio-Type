import Portfolio from "../portfolio/Portfolio";

export default function Gallery() {
  return (
    <div className="" style={{margin:'50px 0'}}>
      <div className="container">
        <h1 className="title">My Portfolio</h1>
      </div>
      <Portfolio />
    </div>
  )
}
