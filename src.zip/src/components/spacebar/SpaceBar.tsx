import style from './spacebar.module.scss';
export default function SpaceBar() {
  return (
    <div className={style.separated}></div>
  )
}
